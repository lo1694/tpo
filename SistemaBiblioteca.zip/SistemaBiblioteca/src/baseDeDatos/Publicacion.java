/** Clase publicaci�n
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class Publicacion {
	private String titulo;
	private int a�oEdicion;
	private Autor autor;
	private int codigoInterno;
	private static int siguienteCodigoDisponible=1;
	private String descripcion;
	private Editorial editorial;
	
	/**Constructor sin par�metros (7.1)
	 * 
	 */
	public Publicacion() {}

	/** Lo solicitado en el item 7.2
	 * @param titulo
	 * @param a�oEdicion
	 * @param autor
	 * @param descripcion
	 * @param editorial
	 */
	public Publicacion(String titulo, int a�oEdicion, Autor autor, String descripcion, Editorial editorial) {
		this.titulo = titulo;
		this.a�oEdicion = a�oEdicion;
		this.autor = autor;
		this.descripcion = descripcion;
		this.editorial = editorial;
	}

	/**Accesadores y mutadores por atributo
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * @param titulo the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * @return the a�oEdicion
	 */
	public int getA�oEdicion() {
		return a�oEdicion;
	}

	/**
	 * @param a�oEdicion the a�oEdicion to set
	 */
	public void setA�oEdicion(int a�oEdicion) {
		this.a�oEdicion = a�oEdicion;
	}

	/**
	 * @return the autor
	 */
	public Autor getAutor() {
		return autor;
	}

	/**
	 * @param autor the autor to set
	 */
	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	/**
	 * @return the codigoInterno
	 */
	public int getCodigoInterno() {
		return codigoInterno;
	}

	/** Lo solicitado en el item 7.4
	 * @param codigoInterno the codigoInterno to set
	 */
	public void setCodigoInterno(int codigoInterno) {
		this.codigoInterno = siguienteCodigoDisponible;
	}

	/**
	 * @return the siguienteCodigoDisponible
	 */
	public static int getSiguienteCodigoDisponible() {
		return siguienteCodigoDisponible;
	}

	/** Lo solicitado en el item 7.4
	 * @param siguienteCodigoDisponible the siguienteCodigoDisponible to set
	 */
	public static void setSiguienteCodigoDisponible(int siguienteCodigoDisponible) {
		Publicacion.siguienteCodigoDisponible = siguienteCodigoDisponible+1;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @return the editorial
	 */
	public Editorial getEditorial() {
		return editorial;
	}

	/**
	 * @param editorial the editorial to set
	 */
	public void setEditorial(Editorial editorial) {
		this.editorial = editorial;
	}

	/** Lo solicitado en el item 7.5
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Publicacion [titulo=" + titulo + ", a�oEdicion=" + a�oEdicion + ", autor=" + autor + ", codigoInterno="
				+ codigoInterno + ", descripcion=" + descripcion + ", editorial=" + editorial + "]";
	}
	
	
	
	
	

}

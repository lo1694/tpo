/**
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class LibroConCd extends Libro {
	private Cd cd;

	/**
	 * 
	 */
	public LibroConCd() {
	}

	/**
	 * @param tema
	 * @param version
	 * @param cantidadTomos
	 * @param cantidadPaginas
	 * @param isbn
	 * @param idioma
	 * @param cd
	 */
	public LibroConCd(String tema, int version, int cantidadTomos, int cantidadPaginas, Isbn isbn, String idioma, Cd cd) {
		super(tema, version, cantidadTomos, cantidadPaginas, isbn, idioma);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the cd
	 */
	public Cd getCd() {
		return cd;
	}

	/**
	 * @param cd the cd to set
	 */
	public void setCd(Cd cd) {
		this.cd = cd;
	}
	
	
	public String imprimir()
	{
		return "Tema: "+this.cd;
	}
	
	
	
	
	
	
}

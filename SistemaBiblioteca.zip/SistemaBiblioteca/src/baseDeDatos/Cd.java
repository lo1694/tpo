/** Item 11
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class Cd {

	private String tema;
	private Issn issn;
	private Tiempo duracion;
	private int cantidadPistas;
	
	
	/**Constructor sin par�metros 11.1
	 * 
	 */
	public Cd() {
	}

	/**
	 * @param tema
	 * @param issn
	 * @param duracion
	 * @param cantidadPistas
	 */
	public Cd(String tema, Issn issn, Tiempo duracion, int cantidadPistas) {
		this.tema = tema;
		this.issn = issn;
		this.duracion = duracion;
		this.cantidadPistas = cantidadPistas;
	}

	/**
	 * @return the tema
	 */
	public String getTema() {
		return tema;
	}

	/**
	 * @param tema the tema to set
	 */
	public void setTema(String tema) {
		this.tema = tema;
	}

	/**
	 * @return the issn
	 */
	public Issn getIssn() {
		return issn;
	}

	/**
	 * @param issn the issn to set
	 */
	public void setIssn(Issn issn) {
		this.issn = issn;
	}

	/**
	 * @return the duracion
	 */
	public Tiempo getDuracion() {
		return duracion;
	}

	/**
	 * @param duracion the duracion to set
	 */
	public void setDuracion(Tiempo duracion) {
		this.duracion = duracion;
	}

	/**
	 * @return the cantidadPistas
	 */
	public int getCantidadPistas() {
		return cantidadPistas;
	}

	/**
	 * @param cantidadPistas the cantidadPistas to set
	 */
	public void setCantidadPistas(int cantidadPistas) {
		this.cantidadPistas = cantidadPistas;
	}
	
	
	/**
	 * Metodo imprimir
	 * @return
	 */
	public String imprimir()
	{
		return "Tema: "+this.tema+" Issn: "+this.issn+" Duraci�n: "+this.duracion;
	}
	
	
	
	
}

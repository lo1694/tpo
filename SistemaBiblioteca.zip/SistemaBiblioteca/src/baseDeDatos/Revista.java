/** Clase solicitada en el item 9
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class Revista {
	
	private String nombre;
	private int periocidad;
	private int cantidadEjemplaresPeriodicos;
	private int cantidadPaginas;
	private Issn issn;
	private boolean traducida;
	
	
	/**Constructor sin par�metros solicitado en el item 9.1
	 * 
	 */
	public Revista() {
	}

	/**Constructor con todos los par�metros solicitado en el item 9.2
	 * @param nombre
	 * @param periocidad
	 * @param cantidadEjemplaresPeriodicos
	 * @param cantidadPaginas
	 * @param issn
	 * @param traducida
	 */
	public Revista(String nombre, int periocidad, int cantidadEjemplaresPeriodicos, int cantidadPaginas, Issn issn,
			boolean traducida) {
		this.nombre = nombre;
		this.periocidad = periocidad;
		this.cantidadEjemplaresPeriodicos = cantidadEjemplaresPeriodicos;
		this.cantidadPaginas = cantidadPaginas;
		this.issn = issn;
		this.traducida = traducida;
	}

	
	
	/**Accesadores y mutadores 9.3 9.4
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the periocidad
	 */
	public int getPeriocidad() {
		return periocidad;
	}

	/**
	 * @param periocidad the periocidad to set
	 */
	public void setPeriocidad(int periocidad) {
		this.periocidad = periocidad;
	}

	/**
	 * @return the cantidadEjemplaresPeriodicos
	 */
	public int getCantidadEjemplaresPeriodicos() {
		return cantidadEjemplaresPeriodicos;
	}

	/**
	 * @param cantidadEjemplaresPeriodicos the cantidadEjemplaresPeriodicos to set
	 */
	public void setCantidadEjemplaresPeriodicos(int cantidadEjemplaresPeriodicos) {
		this.cantidadEjemplaresPeriodicos = cantidadEjemplaresPeriodicos;
	}

	/**
	 * @return the cantidadPaginas
	 */
	public int getCantidadPaginas() {
		return cantidadPaginas;
	}

	/**
	 * @param cantidadPaginas the cantidadPaginas to set
	 */
	public void setCantidadPaginas(int cantidadPaginas) {
		this.cantidadPaginas = cantidadPaginas;
	}

	/**
	 * @return the issn
	 */
	public Issn getIssn() {
		return issn;
	}

	/**
	 * @param issn the issn to set
	 */
	public void setIssn(Issn issn) {
		this.issn = issn;
	}

	/**
	 * @return the traducida
	 */
	public boolean isTraducida() {
		return traducida;
	}

	/**
	 * @param traducida the traducida to set
	 */
	public void setTraducida(boolean traducida) {
		this.traducida = traducida;
	}

	/**Item 9.5
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Revista [nombre=" + nombre + ", periocidad=" + periocidad + ", cantidadEjemplaresPeriodicos="
				+ cantidadEjemplaresPeriodicos + ", cantidadPaginas=" + cantidadPaginas + ", issn=" + issn
				+ ", traducida=" + traducida + "]";
	}
	
	
	
	
	
	
}

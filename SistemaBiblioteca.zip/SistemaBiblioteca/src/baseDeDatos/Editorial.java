/** Clase Editorial
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
/**
 * @author Administrador
 *
 */
/**
 * @author Administrador
 *
 */
public class Editorial
{
	private String nombre;
	private int a�oCreacion;
	private String representanteLegal;
	private int codigo;
	private String paisSede;
	
	/**Constructor sin par�metros (6.1)
	 * 
	 */
	public Editorial() {
	}

	/**Constructor con los par�metros de la clase
	 * @param nombre
	 * @param a�oCreacion
	 * @param representanteLegal
	 * @param codigo
	 * @param paisSede
	 */
	public Editorial(String nombre, int a�oCreacion, String representanteLegal, int codigo, String paisSede) {
		this.nombre = nombre;
		this.a�oCreacion = a�oCreacion;
		this.representanteLegal = representanteLegal;
		this.codigo = codigo;
		this.paisSede = paisSede;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Editorial [Nombre=" + nombre + ", A�o de creacion=" + a�oCreacion + ", Representante legal="
				+ representanteLegal + ", c�digo=" + codigo + ", Pais sede=" + paisSede + "]";
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the a�oCreacion
	 */
	public int getA�oCreacion() {
		return a�oCreacion;
	}

	/**
	 * @param a�oCreacion the a�oCreacion to set
	 */
	public void setA�oCreacion(int a�oCreacion) {
		this.a�oCreacion = a�oCreacion;
	}

	/**
	 * @return the representanteLegal
	 */
	public String getRepresentanteLegal() {
		return representanteLegal;
	}

	/**
	 * @param representanteLegal the representanteLegal to set
	 */
	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}

	/**
	 * @return the codigo
	 */
	public int getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the paisSede
	 */
	public String getPaisSede() {
		return paisSede;
	}

	/**
	 * @param paisSede the paisSede to set
	 */
	public void setPaisSede(String paisSede) {
		this.paisSede = paisSede;
	}
	
	
	
	
	
	

}

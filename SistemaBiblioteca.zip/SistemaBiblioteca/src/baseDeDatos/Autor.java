/** La clase autor que hereda de la clase persona
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class Autor extends Persona
{
	private String nacionalidad;
	private Boolean casado;
	
	/**Constructor sin par�metros (5.1)
	 * 
	 */
	public Autor() {
		super();
	}


	/** Constructor con con todos los par�metros (5.2)
	 * @param nombre
	 * @param apellidos
	 * @param rut
	 * @param edad
	 * @param direccion
	 * @param profesion
	 * @param cantidadDeHijos
	 * @param lugarDeTrabajo
	 * @param antiguedadLaboral
	 * @param nacionalidad
	 * @param casado
	 */
	public Autor(String nombre, String apellidos, String rut, int edad, String direccion, String profesion,
			int cantidadDeHijos, String lugarDeTrabajo, int antiguedadLaboral, String nacionalidad, Boolean casado)
	{
		super(nombre, apellidos, rut, edad, direccion, profesion, cantidadDeHijos, lugarDeTrabajo, antiguedadLaboral);
		this.nacionalidad=nacionalidad;
		this.casado=casado;
	}




	/**
	 * @param nombre
	 * @param apellidos
	 * @param rut
	 * @param edad
	 * @param direccion
	 * @param profesion
	 * @param cantidadDeHijos
	 * @param lugarDeTrabajo
	 * @param antiguedadLaboral
	 */
	public Autor(String nombre, String apellidos, String rut, int edad, String direccion, String profesion,
			int cantidadDeHijos, String lugarDeTrabajo, int antiguedadLaboral) {
		super(nombre, apellidos, rut, edad, direccion, profesion, cantidadDeHijos, lugarDeTrabajo, antiguedadLaboral);
	}


	/** M�todo imprimir de la clase (5.5)
	 * @return
	 */
	public String imprimir()
	{
		return super.imprimir()+" Nacionalidad: "+this.nacionalidad+" Casado: "+this.casado;

	}
	
	
	/**
	 * @return the nacionalidad
	 */
	public String getNacionalidad() {
		return nacionalidad;
	}

	/**
	 * @param nacionalidad the nacionalidad to set
	 */
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	/**
	 * @return the casado
	 */
	public Boolean getCasado() {
		return casado;
	}

	/**
	 * @param casado the casado to set
	 */
	public void setCasado(Boolean casado) {
		this.casado = casado;
	}
	
	
	
	
	


	

	
	
	
}



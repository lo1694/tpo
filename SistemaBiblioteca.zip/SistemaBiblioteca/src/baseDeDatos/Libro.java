/**Clase solicitada en el item 8
 * 
 */
package baseDeDatos;

/**
 * @author Administrador
 *
 */
public class Libro {
	
	private String tema;
	private int version;
	private int cantidadTomos;
	private int cantidadPaginas;
	private Isbn isbn;
	private String idioma;
	
	/**
	 * lo solicitado en el item 8.1
	 */
	public Libro() {
	}

	/** lo solicitado en el item 8.2
	 * @param tema
	 * @param version
	 * @param cantidadTomos
	 * @param cantidadPaginas
	 * @param isbn
	 * @param idioma
	 */
	public Libro(String tema, int version, int cantidadTomos, int cantidadPaginas, Isbn isbn, String idioma) {
		this.tema = tema;
		this.version = version;
		if(cantidadTomos<1)
			System.out.println("La cantidad mencionada no corresponde");
		else 
			this.cantidadTomos = cantidadTomos;
		this.cantidadPaginas = cantidadPaginas;
		this.isbn = isbn;
		this.idioma = idioma;
		
		
		
		
	}

	/**lo solicitado en el item 8.3 y 8.4
	 * @return the tema
	 */
	public String getTema() {
		return tema;
	}

	/**
	 * @param tema the tema to set
	 */
	public void setTema(String tema) {
		this.tema = tema;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * @return the cantidadTomos
	 */
	public int getCantidadTomos() {
		return cantidadTomos;
	}

	/**
	 * @param cantidadTomos the cantidadTomos to set
	 */
	public void setCantidadTomos(int cantidadTomos) {
		if(cantidadTomos<1)
			System.out.println("La cantidad mencionada no corresponde");
		else 
			this.cantidadTomos = cantidadTomos;
	}

	/**
	 * @return the cantidadPaginas
	 */
	public int getCantidadPaginas() {
		return cantidadPaginas;
	}

	/**
	 * @param cantidadPaginas the cantidadPaginas to set
	 */
	public void setCantidadPaginas(int cantidadPaginas) {
		this.cantidadPaginas = cantidadPaginas;
	}

	/**
	 * @return the isbn
	 */
	public Isbn getIsbn() {
		return isbn;
	}

	/**
	 * @param isbn the isbn to set
	 */
	public void setIsbn(Isbn isbn) {
		this.isbn = isbn;
	}

	/**
	 * @return the idioma
	 */
	public String getIdioma() {
		return idioma;
	}

	/**
	 * @param idioma the idioma to set
	 */
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}

	/** lo solicitado en el item 8.5
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Libro [tema=" + tema + ", version=" + version + ", cantidadTomos=" + cantidadTomos
				+ ", cantidadPaginas=" + cantidadPaginas + ", isbn=" + isbn + ", idioma=" + idioma + "]";
	}
	
	
	
	
	
}

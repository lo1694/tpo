package baseDeDatos;

/**
 * @author Administrador
 * Inicio de la prueba pr�ctica
 */
public final class Isbn
{

	private String eanInternational;
	private String paisOrigen;
	private String idEditor;
	private String idTitulo;
	private String verificador;
	
	/**
	 * Constructor sin par�metros solicitado en el Item 2.1
	 */
	public Isbn()
	{
		super();
	}

	/**Constructor con los par�metros solicitados en Item 2.2, el resultado de este m�todo establece el verificador. 
	 * @param eanInternational
	 * @param paisOrigen
	 * @param idEditor
	 * @param idTitulo
	 */
	public Isbn(String eanInternational, String paisOrigen, String idEditor, String idTitulo)
	{
		super();
		this.eanInternational = eanInternational;
		this.paisOrigen = paisOrigen;
		this.idEditor = idEditor;
		this.idTitulo = idTitulo;
		
		if(eanInternational != "978" || eanInternational != "979" || eanInternational.length()>3)
			System.out.println("el c�digo international no es v�lido");
		if(paisOrigen.length()>4)
			System.out.println("El c�digo del pa�s de origen es demasiado largo");
		if(idEditor.length()>2)
			System.out.println("El Id del editor no es v�lido");
		if(idTitulo.length()>3)
			System.out.println("El Id del t�tulo no es v�lido");
		
		int verificador=0;int i;
		for(i=0;i<=paisOrigen.length()-1;++i)
			verificador+=(i+1)*Integer.parseInt(String.valueOf(paisOrigen.charAt(i)));
		for(i=0;i<=idEditor.length()-1;++i)
			verificador+=(i+5)*Integer.parseInt(String.valueOf(idEditor.charAt(i)));
		for(i=0;i<=idTitulo.length()-1;++i)
			verificador+=(i+7)*Integer.parseInt(String.valueOf(idTitulo.charAt(i)));
		this.verificador=Integer.toString(verificador%11);
	}


	/**M�todo que permite imprimir.  Solicitado en el Item 2.4 
	 * @return
	 */
	public String imprimir()
	{
		return "ISBN - "+this.eanInternational+" - "+this.paisOrigen+" - "+this.idEditor+" - "+this.idTitulo+" - "+this.verificador;
	}

	/**
	 * @return the eanInternational
	 */
	public String getEanInternational() {
		return eanInternational;
	}

	/**
	 * @param eanInternational the eanInternational to set
	 */
	public void setEanInternational(String eanInternational) {
		this.eanInternational = eanInternational;
	}

	/**
	 * @return the paisOrigen
	 */
	public String getPaisOrigen() {
		return paisOrigen;
	}

	/**
	 * @param paisOrigen the paisOrigen to set
	 */
	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	/**
	 * @return the idEditor
	 */
	public String getIdEditor() {
		return idEditor;
	}

	/**
	 * @param idEditor the idEditor to set
	 */
	public void setIdEditor(String idEditor) {
		this.idEditor = idEditor;
	}

	/**
	 * @return the idTitulo
	 */
	public String getIdTitulo() {
		return idTitulo;
	}

	/**
	 * @param idTitulo the idTitulo to set
	 */
	public void setIdTitulo(String idTitulo) {
		this.idTitulo = idTitulo;
	}

	/**
	 * @return the verificador
	 */
	public String getVerificador() {
		return verificador;
	}

	/**
	 * @param verificador the verificador to set
	 */
	public void setVerificador(String verificador) {
		this.verificador = verificador;
	}
}


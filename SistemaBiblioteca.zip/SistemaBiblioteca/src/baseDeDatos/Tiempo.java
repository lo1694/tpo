/**Clase solicitada en el item 10
 * 
 */
package baseDeDatos;
/**
 * @author Administrador
 *
 */
public class Tiempo {

	private int horas;
	private int minutos;
	private int segundos;
	private String displayTiempo;
	
	/**Item 10.1
	 * 
	 */
	public Tiempo() {
	}


	/**Item 10.2
	 * @param horas
	 * @param minutos
	 * @param segundos
	 * @param displayTiempo
	 */
	public Tiempo(int horas, int minutos, int segundos, String displayTiempo) {
		this.horas = horas;
		if(minutos>=0 && minutos <=59)
			this.minutos = minutos;
		else System.out.println("Valores fuera del rango de minutos");
		if(segundos>=0 && segundos <=59)
			this.segundos = segundos;
		else System.out.println("Valores fuera del rango de segundos");
		this.displayTiempo = displayTiempo;
	}
	
	/**
	 * Lo solicitado en el item 10.5
	 * @return
	 */
	public int duracionTotalminutos()
	{
		return minutos+(horas*60);
	}
	
	/**
	 * Lo solicitado en el item 10.6
	 * @return
	 */
	public int duracionTotalsegundos()
	{
		//cada hora tiene 3600 segundos
		return segundos+(minutos*60)+(horas*3600);
	}
	
	
	/**
	 * Metodo imprimir
	 * @return
	 */
	public String imprimir()
	{
		return "Hora: "+this.horas+" Minutos: "+this.minutos+" Segundos: "+this.segundos;
		
	}
	

	/**Item 10.3 y 10.4
	 * @return the horas
	 */
	public int getHoras() {
		return horas;
	}


	/**
	 * @param horas the horas to set
	 */
	public void setHoras(int horas) {
		this.horas = horas;
	}


	/**
	 * @return the minutos
	 */
	public int getMinutos() {
		return minutos;
	}


	/**
	 * @param minutos the minutos to set
	 */
	public void setMinutos(int minutos) {
		if(minutos>=0 && minutos <=59)
			this.minutos = minutos;
		else System.out.println("Valores fuera del rango de minutos");
	}


	/**
	 * @return the segundos
	 */
	public int getSegundos() {
		return segundos;
	}


	/**
	 * @param segundos the segundos to set
	 */
	public void setSegundos(int segundos) {
		if(segundos>=0 && segundos <=59)
			this.segundos = segundos;
		else System.out.println("Valores fuera del rango de segundos");
	}


	/**
	 * @return the displayTiempo
	 */
	public String getDisplayTiempo() {
		return displayTiempo;
	}


	/**
	 * @param displayTiempo the displayTiempo to set
	 */
	public void setDisplayTiempo(String displayTiempo) {
		this.displayTiempo = displayTiempo;
	}
	
	
	
	
}

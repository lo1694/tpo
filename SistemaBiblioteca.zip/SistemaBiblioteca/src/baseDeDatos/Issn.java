package baseDeDatos;

/** El Issn del proyecto
 * @author Administrador
 *
 */
public final class Issn
{
	private String grupoUno;
	private String grupoDos;
	private String digitoControl;
	
	
	/**
	 * Constructor sin par�metros (3.1)
	 */
	public Issn() {
		super();
	}

	/**Constructor solicitado entregar� el digitoControl (3.2)
	 * @param grupoUno
	 * @param grupoDos
	 */
	public Issn(String grupoUno, String grupoDos) {
		super();
		this.grupoUno = grupoUno;
		this.grupoDos = grupoDos;
		
		if(grupoUno.length()>4)
			System.out.println("El primer grupo de cifras excede el largo normal");
		if(grupoDos.length()>3)
			System.out.println("El primer segundo grupo de cifras excede el largo normal");
		String issn=grupoUno+grupoDos;
		int digito=0;int x=0;int y=8;
		for(int i=0;i<=issn.length()-1;++i)
		{
			x=Integer.parseInt(String.valueOf(issn.charAt(i)));
			//System.out.println(x+"*"+y+"="+x*y);
			digito+=x*y;
			y--;
		}
		this.digitoControl=String.valueOf((-(digito%11)+11));
	}
	
	/** M�todo imprimir solicitado (3.5)
	 * @return
	 */
	public String imprimir()
	{
		return "ISSN - "+this.grupoUno+" - "+this.grupoDos+this.digitoControl;
		
	}

	/**
	 * @return the grupoUno
	 */
	public String getGrupoUno() {
		return grupoUno;
	}


	/**
	 * @param grupoUno the grupoUno to set
	 */
	public void setGrupoUno(String grupoUno) {
		this.grupoUno = grupoUno;
	}


	/**
	 * @return the grupoDos
	 */
	public String getGrupoDos() {
		return grupoDos;
	}


	/**
	 * @param grupoDos the grupoDos to set
	 */
	public void setGrupoDos(String grupoDos) {
		this.grupoDos = grupoDos;
	}


	/**
	 * @return the digitoControl
	 */
	public String getDigitoControl() {
		return digitoControl;
	}


	/**
	 * @param digitoControl the digitoControl to set
	 */
	public void setDigitoControl(String digitoControl) {
		this.digitoControl = digitoControl;
	}
}



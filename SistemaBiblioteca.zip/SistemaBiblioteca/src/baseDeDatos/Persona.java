/** Clase abstracta Persona
 * 
 */
package baseDeDatos;
/**
 * @author Administrador
 *
 */
public class Persona
{
	private String nombre;
	private String apellidos;
	private String rut;
	private int edad;
	private String direccion;
	private String profesion;
	private int cantidadDeHijos;
	private String lugarDeTrabajo;
	private int antiguedadLaboral;
	
	
	
	/** Constructor sin par�metros (4.1)
	 * 
	 */
	public Persona() {
		super();
	}

	/**Constructor con todos los par�metros solicitados (4.2)
	 * @param nombre
	 * @param apellidos
	 * @param rut
	 * @param edad
	 * @param direccion
	 * @param profesion
	 * @param cantidadDeHijos
	 * @param lugarDeTrabajo
	 * @param antiguedadLaboral
	 */
	public Persona(String nombre, String apellidos, String rut, int edad, String direccion, String profesion,
			int cantidadDeHijos, String lugarDeTrabajo, int antiguedadLaboral) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.rut = rut;
		this.edad = edad;
		this.direccion = direccion;
		this.profesion = profesion;
		this.cantidadDeHijos = cantidadDeHijos;
		this.lugarDeTrabajo = lugarDeTrabajo;
		this.antiguedadLaboral = antiguedadLaboral;
	}
	
	/** M�todo imprimir de la clase (4.5)
	 * @return
	 */
	public String imprimir()
	{
		return "Nombre: "+this.nombre+" "+this.apellidos+" Rut: "+this.rut+" Edad: "+this.edad+" Direcci�n: "+this.direccion+" Profesi�n: "+this.profesion+" Cantidad de hijos: "+this.cantidadDeHijos+" Lugar de trabajo: "+this.lugarDeTrabajo+" Antiguedad laboral: "+this.antiguedadLaboral;
		
	}
	

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the rut
	 */
	public String getRut() {
		return rut;
	}

	/**
	 * @param rut the rut to set
	 */
	public void setRut(String rut) {
		this.rut = rut;
	}

	/**
	 * @return the edad
	 */
	public int getEdad() {
		return edad;
	}

	/**
	 * @param edad the edad to set
	 */
	public void setEdad(int edad) {
		this.edad = edad;
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	/**
	 * @return the profesion
	 */
	public String getProfesion() {
		return profesion;
	}

	/**
	 * @param profesion the profesion to set
	 */
	public void setProfesion(String profesion) {
		this.profesion = profesion;
	}

	/**
	 * @return the cantidadDeHijos
	 */
	public int getCantidadDeHijos() {
		return cantidadDeHijos;
	}

	/**
	 * @param cantidadDeHijos the cantidadDeHijos to set
	 */
	public void setCantidadDeHijos(int cantidadDeHijos) {
		this.cantidadDeHijos = cantidadDeHijos;
	}

	/**
	 * @return the lugarDeTrabajo
	 */
	public String getLugarDeTrabajo() {
		return lugarDeTrabajo;
	}

	/**
	 * @param lugarDeTrabajo the lugarDeTrabajo to set
	 */
	public void setLugarDeTrabajo(String lugarDeTrabajo) {
		this.lugarDeTrabajo = lugarDeTrabajo;
	}

	/**
	 * @return the antiguedadLaboral
	 */
	public int getAntiguedadLaboral() {
		return antiguedadLaboral;
	}

	/**
	 * @param antiguedadLaboral the antiguedadLaboral to set
	 */
	public void setAntiguedadLaboral(int antiguedadLaboral) {
		this.antiguedadLaboral = antiguedadLaboral;
	}
}

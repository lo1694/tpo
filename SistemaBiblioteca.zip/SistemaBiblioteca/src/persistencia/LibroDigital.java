/**Item 14
 * 
 */
package persistencia;
import java.util.HashMap;
import baseDeDatos.Isbn;
import baseDeDatos.Libro;
import baseDeDatos.Persona;


/**
 * @author Administrador
 *
 */
public class LibroDigital extends Libro {
	private String link;
	private int numeroVisitas;
	HashMap<Integer,Persona>visita = new HashMap<Integer,Persona>();
	
	/**Item 14.9
	 * 
	 */
	public LibroDigital() {
		super();
	}
	
	/**Item 14.10
	 * @param tema
	 * @param version
	 * @param cantidadTomos
	 * @param cantidadPaginas
	 * @param isbn
	 * @param idioma
	 * @param link
	 * @param numeroVisitas
	 */
	public LibroDigital(String tema, int version, int cantidadTomos, int cantidadPaginas, Isbn isbn, String idioma, String link, int numeroVisitas) {
		super(tema, version, cantidadTomos, cantidadPaginas, isbn, idioma);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}
	/**
	 * @param link the link to set
	 */
	
	public void setLink(String link) {
		int punto=0;
		for(int i=0;i<link.length();i++)
		{
			String var=link.substring(i, i+1);
			if (var.contains("."))
				punto+=1;
		}
		if (punto>=2)
			this.link=link;
		else System.out.println("link no v�lido");
	}
	/**
	 * @return the numeroVisitas
	 */
	public int getNumeroVisitas() {
		return numeroVisitas;
	}
	/**
	 * @param numeroVisitas the numeroVisitas to set
	 */
	public void setNumeroVisitas(int numeroVisitas) {
		this.numeroVisitas = numeroVisitas;
	}
	
	/**
	 * Item 14.3
	 */
	public String registrarVisita()
	{
		int x=0;
		visita.put(x,new Persona());
		x+=1;
		return "Se ha registrado una nueva visita";
	}
	
	/**
	 * M�todo imprimir de la clase;
	 * @return
	 */
	public String imprimir()
	{
		return "Link: "+this.link+" N� visitas: "+this.visita;
	}
}

/**Item 14
 * 
 */
package persistencia;
import java.util.HashMap;
import baseDeDatos.Editorial;
import baseDeDatos.Publicacion;
import baseDeDatos.Autor;


/**
 * @author Administrador
 *
 */

/**
 * HashMaps est�ticos
 */
public class Archivo {
	static HashMap<String,Autor>autores = new HashMap<String,Autor>();
	int i=0;
	static {
		autores.put("a1",new Autor("Roberto","Gomez","10.279.036-7",25,"Orella 232","Director",2,"Zofri",15,"chileno",false));
		autores.put("a2",new Autor("Andres","Rossel","7.9713.163-2",22,"Libertad 316","Supervisor",3,"Escuela E-70",5,"chileno",true));
    	}

	static HashMap<String,Editorial>editoriales = new HashMap<String,Editorial>();
	static {
		editoriales.put("e1",new Editorial("Santillana",1989,"Ismael Pereira",246,"Mexico"));
		editoriales.put("e2",new Editorial("Romulo y Remo",1979,"Gabriel Rojas",984,"Ecuador"));
	}
	
	static HashMap<String,Publicacion>publicaciones = new HashMap<String,Publicacion>();
	static {
		publicaciones.put("p1",new Publicacion("Mi vida",1997,autores.get(1),"curiosidades de la vida personal",editoriales.get(2)));
		publicaciones.put("p2",new Publicacion("La copa rota",1983,autores.get(2),"cuento de como se rompi� la copa",editoriales.get(1)));
	   	}

	/**
	 * M�todos solicitados
	 */
	public void agregar(String nombreColeccion,Object elemento)
	{
		if (elemento.equals(autores))
			autores.put(nombreColeccion,new Autor());
		if (elemento.equals(editoriales))
				editoriales.put(nombreColeccion, new Editorial());
		if (elemento.equals(publicaciones))
				publicaciones.put(nombreColeccion, new Publicacion());
	}


	public void eliminar(String nombreColeccion,Object elemento)
	{
		if (elemento.equals(autores))
			autores.remove(nombreColeccion);
		if (elemento.equals(editoriales))
				editoriales.remove(nombreColeccion);
		if (elemento.equals(publicaciones))
				publicaciones.remove(nombreColeccion);
		else System.out.println("Ese elemento no se encuentra registrado");
	}
	
	public boolean consultar(Object elemento)
	{
		if (elemento.equals(autores))
			{
			autores.containsKey(elemento);
			return true;
			}
		else if (elemento.equals(editoriales))
			{
			editoriales.containsKey(elemento);
			return true;
			}
		else if (elemento.equals(publicaciones))
			{
			publicaciones.containsKey(elemento);
			return true;
			}
		else return false;
	}
	
}

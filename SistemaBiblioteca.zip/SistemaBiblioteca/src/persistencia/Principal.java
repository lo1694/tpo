/**
 * M�tood Main
 */
package persistencia;

import baseDeDatos.Autor;
import baseDeDatos.Editorial;
import baseDeDatos.Publicacion;

/**
 * @author Administrador
 *
 */
public class Principal {

	/**
	 * 
	 */
	public Principal() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Autor autor=new Autor();
		Editorial editorial=new Editorial();
		Publicacion publicacion=new Publicacion();
		
		
		
	}

}
